module Paperclip
  VERSION = "2.4.0" unless defined? Paperclip::VERSION
end
